/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

/**
 *
 * @author mark4
 */
public class P5_10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int count = 0;
        for (int i = 100; i <= 200; i++) {
            if (i % 3 == 0 && i % 4 == 0) {
                System.out.print(i);
                System.out.print("\t");
                count = count + 1;
                if (count >= 10) {
                    count = 0;
                    System.out.print("\n");
                }
            }
        }

        System.out.print("\n");
        // TODO code application logic here
    }

}

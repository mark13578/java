/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

/**
 *
 * @author mark4
 */
public class P5_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.print("Ceisius");
        System.out.print("\t");
        System.out.println("Fahrenheit");
        for (int i = 0; i <=100; i +=2) {
            double f = i * 1.8 + 32;
            System.out.print(i);
            System.out.print("\t");
            System.out.print(f);
            System.out.print("\n");
        }
        // TODO code application logic here
    }
    
}

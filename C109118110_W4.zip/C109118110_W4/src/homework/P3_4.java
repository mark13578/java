/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;
import java.util.Arrays;

/**
 *
 * @author mark4
 */
public class P3_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        String[] arrayStr = new String[] {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
       System.out.println(Arrays.toString(arrayStr));
        int x = (int) (Math.random() * 12);
        System.out.printf("%d 月為", x+1);
        System.out.print("\n");
        System.out.println(arrayStr[x]);
        // TODO code application logic here
    }

}

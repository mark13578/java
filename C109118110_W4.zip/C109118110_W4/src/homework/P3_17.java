/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

import java.util.Scanner;

/**
 *
 * @author mark4
 */
public class P3_17 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        while (true) {
            System.out.println("*******************************");
            System.out.println("--------Welcome to the guessing game--------");
            System.out.println("Please enter a number:（scissor(0), rock(1), paper(2) )");
            Scanner sc = new Scanner(System.in);
            int person = sc.nextInt(); //獲取使用者輸入
            int computer = (int) (Math.random() * 3); //電腦隨機出拳
            String per = "User";
            String com = "Computer";
            //使用者出拳
            switch (person) {
                case 0:
                    per = "scissor";
                    break;
                case 1:
                    per = "rock";
                    break;
                case 2:
                    per = "paper";
                    break;
            }
            //電腦出拳
            switch (computer) {
                case 0:
                    com = "scissor";
                    break;
                case 1:
                    com = "rock";
                    
                    break;
                case 2:
                    com = "paper";
                    break;
            }

            //根據出拳判斷輸贏
            if (person == 2 && computer == 0 || person == 0 && computer == 1 || person == 1 && computer == 2) {
                System.out.println("The computer is " + com + ". You are " + per + ".");
                System.out.println(" You lose! Try again!");
                //System.out.println();
            } else if (person == computer) {
                System.out.println("The computer is " + com + ". You are " + per + " too.");
                System.out.println(" It is a draw");
                // System.out.println();
            } else {
                System.out.println("The computer is " + com + ". You are " + per + ".");
                System.out.println(" You won!");
                System.out.println("Game Over!");;
                break;
            }
        }

        // TODO code application logic here
    }

}

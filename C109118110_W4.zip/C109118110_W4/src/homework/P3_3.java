/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

import java.util.Scanner;

/**
 *
 * @author mark4
 */
public class P3_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        //Generate two random single-digit integers
        int num1 = (int) (Math.random() * 10);
        int num2 = (int) (Math.random() * 10);

        //Inspect two number's size, if num1<num2, num2-num1
        int temp;
        if (num1 > num2) {
            temp = num1 - num2;
            System.out.print("What is " + num1 + " - " + num2 + "?");
            int answer = input.nextInt();
            if (answer == temp) {
                System.out.println("You are correct!");
            } else {
                System.out.println("Your answer is wrong!");
                System.out.println(num1 + " - " + num2 + " should be " + (num1 - num2));
            }
        } else if (num1 == num2) {
            temp = 0;
            System.out.print("What is " + num1 + " - " + num2 + "?");
            int answer = input.nextInt();
             if (answer == temp) {
                System.out.println("You are correct!");
            } else {
                System.out.println("Your answer is wrong!");
                System.out.println(num1 + " - " + num1 + " should be " + (num1 - num2));
            }
        } else {
            temp = num2 - num1;
            System.out.print("What is " + num2 + " - " + num1 + "?");
            int answer = input.nextInt();
             if (answer == temp) {
                System.out.println("You are correct!");
            } else {
                System.out.println("Your answer is wrong!");
                System.out.println(num2 + " - " + num1 + " should be " + (num2 - num1));
            }
        }
        //Input the answer

        // TODO code application logic here
    }

}

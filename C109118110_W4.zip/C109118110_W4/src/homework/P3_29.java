/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

//import java.util.InputMismatchException; 例外：IO Error，空指標，空值
import java.util.Scanner;

/**
 *
 * @author mark4
 */
public class P3_29 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter circle1's center x-, y-coordinates, and radius:");
        double x1 = scan.nextDouble();

        double  y1 = scan.nextDouble();

        double r1 = scan.nextDouble();
        System.out.println("Enter circle2's center x-, y-coordinates, and radius:");
        double x2 = scan.nextDouble();

        double y2 = scan.nextDouble();

        double r2 = scan.nextDouble();
        double rMin = Math.pow(r1 - r2, 2);
        double rMax =Math.pow(r1 + r2, 2);
        double copyR =  (Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));
        if (rMin > copyR && r2 < r1) {
            System.out.println("Circle2 is inside circle1");
        
        } else if (copyR > rMin && copyR < rMax) {
            System.out.println("Circle2 overlaps circle1");
     
        } else if (copyR > rMax) {
            System.out.println("Circle2 does not overlap circle1");
        }
        // TODO code application logic here
    }

}

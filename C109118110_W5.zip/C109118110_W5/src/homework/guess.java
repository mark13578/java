/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

import java.util.Scanner;

/**
 *
 * @author mark4
 */
public class guess {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int number;
        int guess;
        number = 1 + (int) (Math.random() * 100);
// Print out the magic number
        System.out.println("Magic Number:" + number);
        Scanner input = new Scanner(System.in);
        do {
            System.out.println("Please enter a number 1-100:");
            guess = input.nextInt();
            if (guess == number) {
                System.out.print("Yes, the number is ");
                System.out.println(guess);
            } else if (guess > number) {
                System.out.println("Your guess is too high!");
            } else {
                System.out.println("Your guess is too low!");
            }
        } while (guess != number);
        // TODO code application logic here
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

/**
 *
 * @author mark4
 */
public class P5_27 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int count = 0;
        int count2 = 0;
        for (int i = 2014; i <= 2114; i++) {
            if ((i % 4 == 0 && i % 100 != 0) || (i %400==0)){
                
                    System.out.print(i);
                    System.out.print("\t");
                    count = count + 1;
                    count2 = count2 + 1;
                
            }
            if (count == 10) {
                count = 0;
                System.out.println();
            }

        }
        System.out.println();
        System.out.println(count2);
        // TODO code application logic here
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

import java.util.Scanner;

/**
 *
 * @author mark4
 */
public class P5_51 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int year = 0;
        while (year != -1) {
            System.out.print("Enter year:");
            year = input.nextInt();
            if (year != -1) {
                if (year % 4 == 0) {
                    if (year % 100 == 0) {
                        if (year % 400 == 0) {
                            System.out.println("It is leap year.");
                        } else {
                            System.out.println("It is not leap year.");
                        }
                    } else {
                        System.out.println("It is leap year.");
                    }
                } else {
                    System.out.println("It is not leap year.");
                }
            } else {
                System.out.println("Over.");
            }
        }
        // TODO code application logic here
    }
}

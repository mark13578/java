/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

/**
 *
 * @author mark4
 */
public class P5_13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int n;
        for (int i = 1; i <150; i++) {
            if (i * i>12000) {
                System.out.printf("%d", i-1);
                System.out.println();
                break;
                
            } 
        }
        // TODO code application logic here
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

/**
 *
 * @author mark4
 */
public class P5_24 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double molecular;
        double denominator;
        double count;
        count = 0;
        for (int i = 1; i <= 49; i++) {
            double temp;
            molecular = 2 * i - 1;
            denominator = 2 * i;
            temp = molecular / denominator;
            count = count +temp;

        }
        System.out.println(count);

        // TODO code application logic here
    }

}

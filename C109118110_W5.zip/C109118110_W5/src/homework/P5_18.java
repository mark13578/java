/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

/**
 *
 * @author mark4
 */
public class P5_18 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
          //Pattern A
          System.out.println("Pattern A");
        for (int i = 1; i<=6; i++) {
            for (int j=1; j <=i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
        
        
        //Pattern B
        System.out.println("Pattern B");
        for (int i = 6; i >=1; i--) {
            for (int j=1; j <=i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
        
        //Pattern C
        System.out.println("Pattern C");
        for (int i = 1; i <=6; i++) {
             // 1、獲取空格需要顯示數量
            int spaceNum = 6-i; 
            for(int j=1;j<=spaceNum;j++){  // 需要列印空格的數量
                System.out.print(" ");
            }
            
            // 2、獲取星星需要顯示的數量
            int starNum = i;
            for(int j=1;j<=starNum;j++){ // 需要列印星星的數量
                System.out.print("*");
            }
            // 3、換行
            System.out.println();
        }
        
        //Pattern D
        System.out.println("Pattern D");
        for (int i = 6; i >=1; i--) {
             // 1、獲取空格需要顯示數量
            int spaceNum = 6-i; 
            for(int j=1;j<=spaceNum;j++){  // 需要列印空格的數量
                System.out.print(" ");
            }
            
            // 2、獲取星星需要顯示的數量
            int starNum = i;
            for(int j=1;j<=starNum;j++){ // 需要列印星星的數量
                System.out.print("*");
            }
            // 3、換行
            System.out.println();
        }
        
        // TODO code application logic here
    }
    
}

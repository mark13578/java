/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

/**
 *
 * @author mark4
 */
public class P5_40 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int positive=0;
        int negative=0;
        for (int i = 1; i <=2000000;i++) {
            int temp;
            temp = (int) (Math.random()*2);
            if (temp == 0) {
                positive+=1;
            } else {
                negative+=1;
            }
        }
        System.out.printf("正面：%d次", positive);
        System.out.println();
        System.out.printf("反面：%d次", negative);
        System.out.println();
        // TODO code application logic here
    }
    
}

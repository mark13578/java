/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

import java.util.Scanner;

/**
 *
 * @author mark4
 */
public class P5_17 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the number of lines:");
        
        int x = input.nextInt();
        if (x >= 1 && x <= 15) {
        for (int n = x; n >= 0; n--) {
            if (n != 1) {
            for (int j = n; j > 1; j--) {
                System.out.print(" ");
                System.out.print(j);
            }
            
            for (int j = 1; j <= n ; j++) {
                System.out.print(" ");
                System.out.print(j);
            }
            System.out.println();
            } else {
                 System.out.print(" " + n);
                    }
            }
            System.out.println();
        } else {
            System.out.println("Please input again!");           
        }

        }
    }

        // TODO code application logic here
    





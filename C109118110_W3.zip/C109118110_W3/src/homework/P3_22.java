/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

import java.util.Scanner;

/**
 *
 * @author mark4
 */
public class P3_22 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter a point with two coordinates:");
        double x = input.nextDouble();
        double y = input.nextDouble();

        double distance;
        distance = Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));

        if (distance > 10) {
            System.out.println("Point(" + x + "," + y + ") is outside the circle of radius 10");
        } else if (distance == 10) {
            System.out.println("Point(" + x + "," + y + ") is on the circle of radius 10");
        } else {
            System.out.println("Point(" + x + "," + y + ") is inside the circle of radius 10");
        }
        // TODO code application logic here
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

import java.util.Scanner;

/**
 *
 * @author mark4
 */
public class P3_9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter a status of your identify:\n(0)single filers\n(1)married file jointly\n(2)married file separately\n(3)head of household");
        int opt = input.nextInt();
        switch (opt) {
            // Compute tax for single filers
            case 0:
                System.out.print("Please enter your income per year:");
                int income = input.nextInt();
                double tax;
                if (income > 0 && income <= 8350) {
                    tax = income * 0.10;
                    System.out.println("Your income is " + income + ",and the tax you should pay is " + tax + ".");
                } else if (income > 8350 && income <= 33950) {
                    tax = 8350 * 0.10 + (income - 8350) * 0.15;
                    System.out.println("Your income is " + income + ",and the tax you should pay is " + tax + ".");
                } else if (income > 33950 && income <= 82250) {
                    tax = 8350 * 0.10 + (33950 - 8350) * 0.15 + (income - 33950) * 0.25;
                    System.out.println("Your income is " + income + ",and the tax you should pay is " + tax + ".");
                } else if (income > 82250 && income <= 171550) {
                    tax = 8350 * 0.10 + (33950 - 8350) * 0.15 + (82250 - 33950) * 0.25 + (income - 82250) * 0.28;
                    System.out.println("Your income is " + income + ",and the tax you should pay is " + tax + ".");
                } else if (income > 171550 && income <= 372950) {
                    tax = 8350 * 0.10 + (33950 - 8350) * 0.15 + (82250 - 33950) * 0.25 + (171550 - 82250) * 0.28 + (income - 171550) * 0.33;
                    System.out.println("Your income is " + income + ",and the tax you should pay is " + tax + ".");
                } else if (income > 372950) {
                    tax = 8350 * 0.10 + (33950 - 8350) * 0.15 + (82250 - 33950) * 0.25 + (171550 - 82250) * 0.28 + (372950 - 171550) * 0.33 + (income - 372950) * 0.35;
                    System.out.println("Your income is " + income + ",and the tax you should pay is " + tax + ".");
                } else {
                    System.out.println("Please input again!!");
                }
                break;
            // TODO code application logic here
            // Compute tax for married file jointly
            // or qualifying widow(er)
            case 1:
                System.out.print("Please enter your income per year:");
                int income1 = input.nextInt();
                double tax1;
                if (income1 > 0 && income1 <= 16700) {
                    tax1 = 0.1 * income1;
                    System.out.println("Your income is " + income1 + ",and the tax you should pay is " + tax1 + ".");
                } else if (income1 > 16700 && income1 <= 67900) {
                    tax1 = 16700 * 0.10 + (income1 - 16700) * 0.15;
                    System.out.println("Your income is " + income1 + ",and the tax you should pay is " + tax1 + ".");
                } else if (income1 > 67900 && income1 <= 137050) {
                    tax1 = 16700 * 0.10 + (67900 - 16700) * 0.15 + (income1 - 67900) * 0.25;
                    System.out.println("Your income is " + income1 + ",and the tax you should pay is " + tax1 + ".");
                } else if (income1 > 137050 && income1 <= 208850) {
                    tax1 = 16700 * 0.10 + (67900 - 16700) * 0.15 + (137050 - 67900) * 0.25 + (income1 - 137050) * 0.28;
                    System.out.println("Your income is " + income1 + ",and the tax you should pay is " + tax1 + ".");
                } else if (income1 > 208850 && income1 <= 372950) {
                    tax1 = 16700 * 0.10 + (67900 - 16700) * 0.15 + (137050 - 67900) * 0.25 + (208850 - 137050) * 0.28 + (income1 - 208850) * 0.33;
                    System.out.println("Your income is " + income1 + ",and the tax you should pay is " + tax1 + ".");
                } else if (income1 > 372950) {
                    tax1 = 16700 * 0.10 + (67900 - 16700) * 0.15 + (137050 - 67900) * 0.25 + (208850 - 137050) * 0.28 + (372950 - 208850) * 0.33 + (income1 - 372950) * 0.35;
                    System.out.println("Your income is " + income1 + ",and the tax you should pay is " + tax1 + ".");
                } else {
                    System.out.println("Please input again!!");
                }
                break;
            // Compute tax for married file separately
            case 2:
                System.out.print("Please enter your income per year:");
                int income2 = input.nextInt();
                double tax2;
                if (income2 > 0 && income2 <= 8350) {
                    tax2 = 0.1 * income2;
                    System.out.println("Your income is " + income2 + ",and the tax you should pay is " + tax2 + ".");
                } else if (income2 > 8350 && income2 <= 33950) {
                    tax2 = 8350 * 0.10 + (income2 - 8350) * 0.15;
                    System.out.println("Your income is " + income2 + ",and the tax you should pay is " + tax2 + ".");
                } else if (income2 > 33950 && income2 <= 68525) {
                    tax2 = 8350 * 0.10 + (33950 - 8350) * 0.15 + (income2 - 68525) * 0.25;
                    System.out.println("Your income is " + income2 + ",and the tax you should pay is " + tax2 + ".");
                } else if (income2 > 68525 && income2 <= 104425) {
                    tax2 = 8350 * 0.10 + (33950 - 8350) * 0.15 + (104425 - 68525) * 0.25 + (income2 - 104425) * 0.28;
                    System.out.println("Your income is " + income2 + ",and the tax you should pay is " + tax2 + ".");
                } else if (income2 > 104425 && income2 <= 186475) {
                    tax2 = 8350 * 0.10 + (33950 - 8350) * 0.15 + (104425 - 68525) * 0.25 + (186475 - 104425) * 0.28 + (income2 - 186475) * 0.33;
                    System.out.println("Your income is " + income2 + ",and the tax you should pay is " + tax2 + ".");
                } else if (income2 > 186475) {
                    tax2 = 8350 * 0.10 + (33950 - 8350) * 0.15 + (104425 - 33950) * 0.25 + (186475 - 68525) * 0.28 + (186475 - 104425) * 0.33 + (income2 - 186475) * 0.35;
                    System.out.println("Your income is " + income2 + ",and the tax you should pay is " + tax2 + ".");
                } else {
                    System.out.println("Please input again!!");
                }
                break;
            // Compute tax for head of household
            case 3:
                System.out.print("Please enter your income per year:");
                int income3 = input.nextInt();
                double tax3;
                if (income3 > 0 && income3 <= 11950) {
                    tax3 = 0.1 * income3;
                    System.out.println("Your income is " + income3 + ",and the tax you should pay is " + tax3 + ".");
                } else if (income3 > 11950 && income3 <= 45500) {
                    tax3 = 11950 * 0.10 + (income3 - 45500) * 0.15;
                    System.out.println("Your income is " + income3 + ",and the tax you should pay is " + tax3 + ".");
                } else if (income3 > 45500 && income3 <= 117450) {
                    tax3 = 11950 * 0.10 + (117450 - 11950) * 0.15 + (income3 - 45500) * 0.25;
                    System.out.println("Your income is " + income3 + ",and the tax you should pay is " + tax3 + ".");
                } else if (income3 > 117450 && income3 <= 190200) {
                    tax3 = 11950 * 0.10 + (117450 - 11950) * 0.15 + (117450 - 45500) * 0.25 + (income3 - 117450) * 0.28;
                    System.out.println("Your income is " + income3 + ",and the tax you should pay is " + tax3 + ".");
                } else if (income3 > 190200 && income3 <= 372950) {
                    tax3 = 11950 * 0.10 + (117450 - 11950) * 0.15 + (117450 - 45500) * 0.25 + (190200 - 117450) * 0.28 + (income3 - 190200) * 0.33;
                    System.out.println("Your income is " + income3 + ",and the tax you should pay is " + tax3 + ".");
                } else if (income3 > 372950) {
                    tax3 = 11950 * 0.10 + (117450 - 11950) * 0.15 + (117450 - 45500) * 0.25 + (190200 - 117450) * 0.28 + (372950 - 190200) * 0.33 + (income3 - 372950) * 0.35;
                    System.out.println("Your income is " + income3 + ",and the tax you should pay is " + tax3 + ".");
                } else {
                    System.out.println("Please input again!!");
                }
                break;
            // Display wrong status
            default:
                break;
        }
    }

}

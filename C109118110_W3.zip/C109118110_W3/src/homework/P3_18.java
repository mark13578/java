/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

import java.util.Scanner;

/**
 *
 * @author mark4
 */
public class P3_18 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.println("請輸入包裹的重量，以計算其運費(單位：pound):");
        double w;
        double price;
        w = reader.nextDouble();

        
        //&&
        if (w > 0 && w <= 2) {
            price = w * 2.5;
            System.out.println("重量為" + w + "，價格為"+ price);
        } else if (w > 2 && w <= 4) {
            price = w * 4.5;
            System.out.println("重量為" + w + "，價格為"+ price);
        } else if (w > 4 && w <=10) {
            price = w * 7.5;
            System.out.println("重量為" + w + "，價格為"+ price);
        } else if (w > 10 && w <= 20 ){
            price = w * 10.5;
            System.out.println("重量為" + w + "，價格為"+ price);
        } else {
            System.out.println("the package cannot be shipped");
        }
        
        
        // TODO code application logic here
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

import java.util.Scanner;

/**
 *
 * @author mark4
 */
public class P3_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter investment amount:");
        System.out.print("Enter a:");
        double a = input.nextDouble();
        System.out.print("Enter b:");
        double b = input.nextDouble();
        System.out.print("Enter c:");
        double c = input.nextDouble();
        //DecimalFormat df = new DecimalFormat("######0.00");

        double p = b * b - 4 * a * c;
        if (p > 0) {
            double r1, r2;
            r1 = (-b + Math.pow(b * b - 4 * a * c, 0.5)) / (2 * a);
            r2 = (-b - Math.pow(b * b - 4 * a * c, 0.5)) / (2 * a);
            System.out.printf("The equation has two roots %.6f and %.6f\n", r1, r2);
        } else if (p == 0) {
            double r1;
            r1 = (-b - Math.pow(b * b - 4 * a * c, 0.5)) / (2 * a);
            System.out.printf("The equation has one root %.6f\n" , r1);
        } else {
            System.out.println("The equation has no real roots \n");
        }
        // float r1= b * -1 + Math.sqrt(p, 0.5) / 2*a;
        // TODO code application logic here
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

import java.util.Scanner;

/**
 *
 * @author mark4
 */
public class P3_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("請輸入三個整數數字，讓系統從大排到小:");
        int a1 = input.nextInt();
        int a2 = input.nextInt();
        int a3 = input.nextInt();

        if (a1 < a3) {
            int temp;
            temp = a1;
            a1 = a3;
            a3 = temp;
        }
        if (a2 < a3) {
            int temp;
            temp = a2;
            a2 = a3;
            a3 = temp;
        }

        System.out.print(a1);
        System.out.printf("\n");
        System.out.print(a2);
        System.out.printf("\n");
        System.out.print(a3);
        System.out.printf("\n");
        // TODO code application logic here
    }

   
 

}

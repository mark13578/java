/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

import java.util.Scanner;

/**
 *
 * @author mark4
 */
public class P3_12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int number = 0, d3, d2, d1;
        Scanner reader = new Scanner(System.in);
        System.out.println("Please input a number between 1 and 999.");
        number = reader.nextInt();
        // 判斷Number在1~99999的條件
        if (number >= 1 && number <= 999) {
            // 計算百位d3
            d3 = number % 1000 / 100;
            // 計算10位
            d2 = number % 100 / 10;
            // 計算個位
            d1 = number % 10;
            // 判斷number是三位數的條件
            if (d3 != 0) { //判斷number是三位數的條件
                System.out.println(number + " is a three-digits number.");
                isAlive(d3 == d1, number);
            } else if (d2 != 0) { //判斷number是兩位數的條件
                System.out.println(number + " is a two-digits number.");
                isAlive(d2 == d1, number);
            } else if (d1 != 0) {
                System.out.println(number + " is an one-digit number.");
                System.out.println(number + " is a palindrome.");
            }
        } else {
            System.err.printf("\n%d不在1至999之間", number);
        }
        reader.close();
    }

    private static void isAlive(boolean is, int number) {
        if (is) {
            System.err.println(number + " is a palindrome.");
        } else {
            System.err.println(number + " is not a palindrome.");
        }
    }
}
// TODO code application logic here


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

import java.util.Scanner;

/**
 *
 * @author mark4
 */
public class P2_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double m;
        double ping;
        
        System.out.println("Enter a number in square meters:");
        m = input.nextDouble();
        ping = m * 0.3025;
        System.out.printf("%.1f square meters is %.3f pings\n", m, ping);
        // TODO code application logic here
    }
    
}

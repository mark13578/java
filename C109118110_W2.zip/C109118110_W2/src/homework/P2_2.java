/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

import java.util.Scanner;

/**
 *
 * @author mark4
 */
public class P2_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        double length;
        double area;
        double volume;
        double height;
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Triangle:");
        length = scanner.nextDouble();
        
        
        
        area = Math.sqrt(3)/4*Math.pow(length, 2);
        volume = area * length;
        
        System.out.printf("The area is %.2f\n", area);
        
        
        System.out.printf("The volume of the Triangular prism is %.2f\n", volume);
        
        // TODO code application logic here
    }
    
}

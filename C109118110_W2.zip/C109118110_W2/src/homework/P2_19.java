/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;


import java.util.Scanner;

/**
 *
 * @author mark4
 */
public class P2_19 {

    /**
     * @param args the command line arguments
     */
    
    
    public static void main(String[] args) {
          Scanner input=new Scanner(System.in); 
        System.out.print("x1:");
        double x1=input.nextDouble(); 
        System.out.print("y1:");
        double y1=input.nextDouble(); 
        System.out.print("x2:");
        double x2=input.nextDouble(); 
        System.out.print("y2:");
        double y2=input.nextDouble(); 
        System.out.print("x3:");
        double x3=input.nextDouble(); 
        System.out.print("y3:");
        double y3=input.nextDouble(); 
        
        
        double side1 = Math.pow(Math.pow(x1-x3, 2)+Math.pow(y1-y3, 2), 0.5);
        double side2 = Math.pow(Math.pow(x2-x3, 2)+Math.pow(y2-y3, 2), 0.5);
        double side3 = Math.pow(Math.pow(x1-x2, 2)+Math.pow(y1-y2, 2), 0.5);
                double s = (side1 + side2 +side3) / 2;
                double area=Math.sqrt(s*(s-side1)*(s-side2)*(s-side3));
        System.out.printf("The area of the triangle is %.1f\n", area);
        // TODO code application logic here
    }
    
}

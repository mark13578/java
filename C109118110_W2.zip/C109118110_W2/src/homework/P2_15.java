/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

import java.util.Scanner;

/**
 *
 * @author mark4
 */
public class P2_15 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          Scanner input=new Scanner(System.in); 
        System.out.print("x1:");
        double x1=input.nextDouble(); ;
        System.out.print("y1:");
        double y1=input.nextDouble(); ;
        System.out.print("x2:");
        double x2=input.nextDouble(); ;
        System.out.print("y2:");
        double y2=input.nextDouble(); 
        
        double x = x2-x1;
        double y  = y2-y1;
        double d = Math.pow(Math.pow(x, 2)+Math.pow(y, 2), 0.5);
        System.out.printf("The distance between the two points is %f\n", d);
        // TODO code application logic here
    }
    
}

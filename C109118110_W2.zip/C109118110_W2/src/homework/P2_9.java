/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

import java.util.Scanner;

/**
 *
 * @author mark4
 */
public class P2_9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner input=new Scanner(System.in); 
        System.out.print("v1:");
        double v1 =input.nextDouble(); 
        System.out.print("v0:");
        double v0 =input.nextDouble();
        double a ; 
        System.out.print("t: ");
        double t =input.nextDouble(); 
        a = (v1 - v0) / t;
        
        System.out.printf("The average acceleration is %.4f\n", a);
     
        // TODO code application logic here
    }
    
}

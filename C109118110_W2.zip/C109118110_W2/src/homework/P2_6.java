/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

import java.util.Scanner;
/**
 *
 * @author mark4
 */
public class P2_6 {
 
  
 
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
 
        System.out.print("Enter a number between 0 and 1000:");
        int aa = input.nextInt();
        
        if(aa<10){
           System.out.print("The multiplication of all digits in " + aa + " is " + aa ); 
           System.out.print("\n" ); 
        }else{
            if(aa<100){
               int a = aa % 10;
               int b = aa / 10;
               
               int multiplication = a * b ;
               System.out.printf("The multiplication of all digits in " + aa + " is " + multiplication ); 
                System.out.print("\n" ); 
            }else{
                if(aa<1000){
                   int a = aa % 10;
                   int b = aa / 100;
                   int c = aa / 10;
                   int d = c/10;
               
                   int multiplication = a * b * d;
                   System.out.print("The multiplication of all digits in " + aa + " is " + multiplication ); 
                    System.out.print("\n" ); 
                }else{
                    if(aa==1000){
                        int a = aa % 10;
                        int b = aa / 100;
                        int c = aa / 10;
                        int d = c/10;
               
                        int multiplication = a * b * d;
                        System.out.print("The multiplication of all digits in " + aa + " is " + multiplication );
                         System.out.print("\n" ); 
                    }
                }
            }
        }
        // TODO code application logic here
    }
    
}

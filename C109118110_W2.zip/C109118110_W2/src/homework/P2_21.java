/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

import java.util.Scanner;

/**
 *
 * @author mark4
 */
public class P2_21 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in); 
        System.out.print("Enter investment amount:");
        double InvestmentAmount = input.nextDouble(); 
        System.out.print("Enter annual interest rate in percentage:");
        double rate =input.nextDouble(); 
        double rate1 = rate / 1200;
        System.out.print("Enter number of years:");
        double y = input.nextDouble(); 
        
        
        
        
        
        double futureInvestmentValue = InvestmentAmount * Math.pow(1+rate1, y*12);
        System.out.printf("Accumulated value is $%.2f\n",  futureInvestmentValue);
        
        // TODO code application logic here
    }
    
}

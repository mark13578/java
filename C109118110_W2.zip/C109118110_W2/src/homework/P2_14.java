/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework;

import java.util.Scanner;

/**
 *
 * @author mark4
 */
public class P2_14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner input=new Scanner(System.in); 
        System.out.print("Enter weight in pounds:");
        double wp;
        wp =input.nextDouble(); 
        System.out.print("Enter height in inches:");
        double hi;
        hi =input.nextDouble(); 
        
        double wkg = wp * 0.45359237;
        double hm = hi * 0.0254;
         
        double bmi;
        
        bmi = wkg / Math.pow(hm, 2);
       /* System.out.println( (double)height/100);*/
        System.out.printf("BMI is %.4f", bmi);
       
        // TODO code application logic here
    }
    
}
